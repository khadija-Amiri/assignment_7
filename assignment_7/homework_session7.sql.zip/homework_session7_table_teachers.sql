
-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `ID` int(50) NOT NULL,
  `First_Name` varchar(50) NOT NULL,
  `Last_Name` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Department` varchar(50) NOT NULL DEFAULT 'CS'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`ID`, `First_Name`, `Last_Name`, `Email`, `Department`) VALUES
(2, 'Fatema', 'ghulami', 'fatima@hotmail.com', 'politics'),
(3, 'Nahid', 'Ashrafi', ' 1234@yahoo.com', 'CS'),
(4, 'khadija', 'amiri', 'amiri@gmail.com', ' economic'),
(5, 'shafiq', ' Ahmadi', 'ahmadi@yahoo.com', 'CS'),
(6, 'Ahmad', 'Ahmadi', 'Ahmad3456@email.com', 'CS'),
(7, 'Ahmad', 'Ahmadi', 'Ahmad3456@email.com', 'CS');
